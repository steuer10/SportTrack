# SportTrack

> Plataforma web para gerenciamento e acompanhamento de treinos esportivos pessoais.

---

## Sobre o Projeto

Atletas amadores não têm uma forma simples de registrar e acompanhar sua evolução nos treinos. Atualmente, utilizam cadernos, planilhas ou simplesmente não registram nada, perdendo histórico de desempenho e dificultando a evolução.

**SportTrack** é uma aplicação web onde o usuário cadastra seus treinos, acompanha sua evolução ao longo do tempo e visualiza seu progresso através de um dashboard interativo.

---

## Funcionalidades

### Requisitos Funcionais (RF)

| ID | Descrição | Status |
|---|---|---|
| RF-01 | Cadastro e autenticação de usuário (login/registro) | ✅ Frontend implementado |
| RF-02 | Registro de treinos (data, tipo, duração, observações) | ✅ Frontend implementado |
| RF-03 | Listagem e histórico completo de treinos | ✅ Frontend implementado — paginação planejada Semana 3 |
| RF-04 | Dashboard com gráfico de evolução e estatísticas | ✅ Frontend implementado |
| RF-05 | Edição e exclusão de treinos | ✅ Frontend implementado |
| RF-06 | Categorização por tipo de esporte | ✅ Frontend implementado |
| RF-07 | Metas semanais com acompanhamento de progresso | ✅ Frontend implementado |
| RF-08 *(novo)* | Filtrar treinos por tipo de esporte e período | 🔲 Planejado — Semana 3 |
| RF-09 *(novo)* | Histórico de evolução das metas | 🔲 Planejado — Semana 3 |

### Requisitos Não Funcionais (RNF)

| ID | Descrição | Status |
|---|---|---|
| RNF-01 | Interface responsiva e mobile-first | ✅ CSS implementado |
| RNF-02 | Autenticação segura com JWT (expiração 7 dias) | 🔲 Backend — Semana 1 |
| RNF-03 | Dados persistidos em banco relacional (PostgreSQL) | 🔲 Backend — Semana 1 |
| RNF-04 | Tempo de resposta inferior a 2s nas consultas | 🔲 A validar no deploy |
| RNF-05 *(novo)* | JWT com expiração de 7 dias | 🔲 Backend — Semana 1 |
| RNF-06 *(novo)* | Senhas com bcrypt (salt rounds = 10) | 🔲 Backend — Semana 1 |

---

## Arquitetura — Modelo C4

### Nível 1 — Contexto

![Diagrama de Contexto C4](docs/c4/c4-nivel1-contexto.svg)

O sistema atende um único tipo de usuário (o atleta). Não há integrações externas no MVP — apenas a infraestrutura de deploy (Render/Railway) e o banco gerenciado como suporte.

---

### Nível 2 — Contêineres

![Diagrama de Contêineres C4](docs/c4/c4-nivel2-containers.svg)

Três contêineres: o Frontend React se comunica com o Backend Express via REST/JSON + JWT, e o Backend persiste os dados no PostgreSQL via Prisma ORM.

---

### Nível 3 — Componentes do Frontend

![Diagrama de Componentes C4](docs/c4/c4-nivel3-componentes.svg)

Estrutura interna do Frontend implementado na Interação 2. Todas as páginas estão funcionais com dados mockados, prontas para integração com o backend.

---

### Nível 4 — Código (Modelo de Dados)

```prisma
model Usuario {
  id        Int      @id @default(autoincrement())
  nome      String
  email     String   @unique
  senha     String
  criadoEm DateTime @default(now())
  treinos   Treino[]
  metas     Meta[]
}

model Treino {
  id          Int      @id @default(autoincrement())
  titulo      String
  tipoEsporte String
  duracaoMin  Int
  observacoes String?
  dataTreino  DateTime
  usuarioId   Int
  usuario     Usuario  @relation(fields: [usuarioId], references: [id])
  criadoEm   DateTime @default(now())
}

model Meta {
  id            Int     @id @default(autoincrement())
  treinosSemana Int
  progresso     Int     @default(0)
  ativa         Boolean @default(true)
  usuarioId     Int
  usuario       Usuario @relation(fields: [usuarioId], references: [id])
  criadoEm     DateTime @default(now())
}
```

---

## Tecnologias

| Tecnologia | Função | Justificativa |
|---|---|---|
| **React** | Front-end | SPA dinâmica, componentização, grande ecossistema |
| **Node.js + Express** | Backend | Leve, rápido e mesma linguagem do frontend |
| **PostgreSQL** | Banco de dados | Confiável para dados relacionais |
| **Prisma ORM** | Acesso ao banco | Facilita consultas e migrações de forma segura |
| **JWT** | Autenticação | Stateless, seguro e simples de implementar |
| **Chart.js** | Gráficos | Visualização de evolução e estatísticas no dashboard |
| **Render / Railway** | Deploy | Gratuito e prático para MVP |

---

## Estrutura do Projeto

```
sporttrack/
├── frontend/
│   ├── src/
│   │   ├── context/        ← AuthContext (estado global)
│   │   ├── services/       ← api.js (chamadas REST + JWT)
│   │   ├── components/     ← Navbar
│   │   ├── pages/          ← Auth · Dashboard · Workouts · Goals
│   │   └── styles/         ← CSS global (mobile-first, tema escuro)
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── backend/                ← Semanas 1-2 (em desenvolvimento)
│   └── prisma/
│       └── schema.prisma
└── docs/
    └── c4/
        ├── c4-nivel1-contexto.svg
        ├── c4-nivel2-containers.svg
        ├── c4-nivel3-componentes.svg
        └── ARQUITETURA_C4.md
```

---

## Cronograma

| Semana | Foco | Status |
|---|---|---|
| 1 | Modelagem do banco, rotas backend e autenticação | 🔲 Em andamento |
| 2 | CRUD de treinos e categorização por esporte | 🔲 Planejado |
| 3 | Dashboard com gráficos e metas semanais | 🔲 Planejado |
| 4 | Integração front/back, testes e deploy | 🔲 Planejado |

> **Interação 2:** iniciou-se pelo **Frontend**. Todas as telas implementadas com dados mockados, prontas para integração com o backend.

---

## Como Executar

### Frontend (disponível agora)

```bash
cd frontend
npm install
npm run dev
# Acesse http://localhost:5173
```

### Backend (Semana 1)

```bash
cd backend
npm install
npx prisma migrate dev
npm run dev
```

### Variáveis de Ambiente (.env)

```env
DATABASE_URL="postgresql://usuario:senha@localhost:5432/sporttrack"
JWT_SECRET="sua_chave_secreta_forte"
JWT_EXPIRES_IN="7d"
PORT=3333
VITE_API_URL=http://localhost:3333/api
```

---

## Autor

Desenvolvido por **VINICIUS**  
Disciplina: DEV WEB
