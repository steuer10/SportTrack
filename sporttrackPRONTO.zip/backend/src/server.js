const express = require("express");
const app = express();

app.use(express.json());

// CORS simples para desenvolvimento
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// Rotas
app.use("/api/auth",    require("./routes/auth.routes"));
app.use("/api/treinos", require("./routes/treino.routes"));
app.use("/api/metas",   require("./routes/meta.routes"));

app.get("/", (req, res) => res.json({ status: "SportTrack API ok" }));

const PORT = process.env.PORT || 3333;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
