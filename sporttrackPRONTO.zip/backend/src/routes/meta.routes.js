const router = require("express").Router();
const auth = require("../middleware/auth.middleware");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// GET /api/metas
router.get("/", auth, async (req, res) => {
  const metas = await prisma.meta.findMany({
    where: { usuarioId: req.usuarioId },
    orderBy: { criadoEm: "desc" },
  });
  res.json(metas);
});

// POST /api/metas
router.post("/", auth, async (req, res) => {
  const { treinosSemana } = req.body;
  if (!treinosSemana)
    return res.status(400).json({ message: "treinosSemana é obrigatório" });

  const meta = await prisma.meta.create({
    data: {
      treinosSemana: Number(treinosSemana),
      usuarioId: req.usuarioId,
    },
  });
  res.status(201).json(meta);
});

// PUT /api/metas/:id
router.put("/:id", auth, async (req, res) => {
  const id = Number(req.params.id);
  const meta = await prisma.meta.findFirst({ where: { id, usuarioId: req.usuarioId } });
  if (!meta) return res.status(404).json({ message: "Meta não encontrada" });

  const atualizada = await prisma.meta.update({
    where: { id },
    data: {
      progresso: req.body.progresso !== undefined ? Number(req.body.progresso) : undefined,
      ativa: req.body.ativa !== undefined ? req.body.ativa : undefined,
      treinosSemana: req.body.treinosSemana ? Number(req.body.treinosSemana) : undefined,
    },
  });
  res.json(atualizada);
});

module.exports = router;
