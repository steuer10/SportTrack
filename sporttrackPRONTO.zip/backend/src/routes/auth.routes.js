const router = require("express").Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// POST /api/auth/register
router.post("/register", async (req, res) => {
  const { nome, email, password } = req.body;
  if (!nome || !email || !password)
    return res.status(400).json({ message: "Campos obrigatórios faltando" });

  const existe = await prisma.usuario.findUnique({ where: { email } });
  if (existe)
    return res.status(409).json({ message: "E-mail já cadastrado" });

  const senha = await bcrypt.hash(password, 10);
  const usuario = await prisma.usuario.create({ data: { nome, email, senha } });

  const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, {
    expiresIn: "7d",
  });

  res.status(201).json({ token, usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email } });
});

// POST /api/auth/login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ message: "Campos obrigatórios faltando" });

  const usuario = await prisma.usuario.findUnique({ where: { email } });
  if (!usuario)
    return res.status(401).json({ message: "Credenciais inválidas" });

  const valido = await bcrypt.compare(password, usuario.senha);
  if (!valido)
    return res.status(401).json({ message: "Credenciais inválidas" });

  const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, {
    expiresIn: "7d",
  });

  res.json({ token, usuario: { id: usuario.id, nome: usuario.nome, email: usuario.email } });
});

module.exports = router;
