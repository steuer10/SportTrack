const router = require("express").Router();
const auth = require("../middleware/auth.middleware");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// GET /api/treinos
router.get("/", auth, async (req, res) => {
  const treinos = await prisma.treino.findMany({
    where: { usuarioId: req.usuarioId },
    orderBy: { dataTreino: "desc" },
  });
  res.json(treinos);
});

// POST /api/treinos
router.post("/", auth, async (req, res) => {
  const { titulo, tipoEsporte, duracaoMin, observacoes, dataTreino } = req.body;
  if (!titulo || !tipoEsporte || !duracaoMin || !dataTreino)
    return res.status(400).json({ message: "Campos obrigatórios faltando" });

  const treino = await prisma.treino.create({
    data: {
      titulo,
      tipoEsporte,
      duracaoMin: Number(duracaoMin),
      observacoes,
      dataTreino: new Date(dataTreino),
      usuarioId: req.usuarioId,
    },
  });
  res.status(201).json(treino);
});

// PUT /api/treinos/:id
router.put("/:id", auth, async (req, res) => {
  const id = Number(req.params.id);
  const treino = await prisma.treino.findFirst({ where: { id, usuarioId: req.usuarioId } });
  if (!treino) return res.status(404).json({ message: "Treino não encontrado" });

  const atualizado = await prisma.treino.update({
    where: { id },
    data: {
      titulo: req.body.titulo,
      tipoEsporte: req.body.tipoEsporte,
      duracaoMin: Number(req.body.duracaoMin),
      observacoes: req.body.observacoes,
      dataTreino: new Date(req.body.dataTreino),
    },
  });
  res.json(atualizado);
});

// DELETE /api/treinos/:id
router.delete("/:id", auth, async (req, res) => {
  const id = Number(req.params.id);
  const treino = await prisma.treino.findFirst({ where: { id, usuarioId: req.usuarioId } });
  if (!treino) return res.status(404).json({ message: "Treino não encontrado" });

  await prisma.treino.delete({ where: { id } });
  res.status(204).send();
});

module.exports = router;
