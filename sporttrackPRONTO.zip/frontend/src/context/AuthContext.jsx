import { createContext, useContext, useState } from "react";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);

  const login = async (email, password) => {
    // TODO: integrate with backend POST /api/auth/login
    const mockUser = { id: 1, nome: "Vinicius", email };
    const mockToken = "mock-jwt-token";
    setUser(mockUser);
    setToken(mockToken);
    localStorage.setItem("sporttrack_token", mockToken);
  };

  const register = async (nome, email, password) => {
    // TODO: integrate with backend POST /api/auth/register
    const mockUser = { id: 1, nome, email };
    const mockToken = "mock-jwt-token";
    setUser(mockUser);
    setToken(mockToken);
    localStorage.setItem("sporttrack_token", mockToken);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("sporttrack_token");
  };

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
