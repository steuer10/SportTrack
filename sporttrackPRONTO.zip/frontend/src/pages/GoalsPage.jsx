import { useState } from "react";

const mockMetas = [
  { id: 1, treinos_semana: 4, progresso: 3, ativa: true },
];

export default function GoalsPage() {
  const [metas, setMetas] = useState(mockMetas);
  const [form, setForm] = useState({ treinos_semana: 3 });
  const [showForm, setShowForm] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    // TODO: chamar metaService.criar(token, form)
    const nova = { id: Date.now(), treinos_semana: Number(form.treinos_semana), progresso: 0, ativa: true };
    setMetas((prev) => [...prev, nova]);
    setShowForm(false);
  };

  const increment = (id) => {
    setMetas((prev) => prev.map((m) =>
      m.id === id ? { ...m, progresso: Math.min(m.progresso + 1, m.treinos_semana) } : m
    ));
  };

  return (
    <div className="page-content">
      <div className="page-header">
        <div>
          <h2>Metas Semanais</h2>
          <p className="page-subtitle">Acompanhe suas metas de treino</p>
        </div>
        <button className="btn-primary" onClick={() => setShowForm(true)}>+ Nova Meta</button>
      </div>

      {showForm && (
        <div className="modal-overlay">
          <div className="modal-card">
            <h3>Nova Meta Semanal</h3>
            <form onSubmit={handleSave}>
              <div className="form-group">
                <label>Treinos por semana</label>
                <input
                  type="number"
                  min={1} max={14}
                  value={form.treinos_semana}
                  onChange={(e) => setForm({ treinos_semana: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancelar</button>
                <button type="submit" className="btn-primary">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="metas-list">
        {metas.map((meta) => {
          const pct = Math.round((meta.progresso / meta.treinos_semana) * 100);
          return (
            <div className="meta-card" key={meta.id}>
              <div className="meta-header">
                <h4>Meta: {meta.treinos_semana} treinos/semana</h4>
                <span className={`meta-badge ${pct >= 100 ? "complete" : ""}`}>
                  {pct >= 100 ? "Concluída!" : "Em andamento"}
                </span>
              </div>
              <div className="meta-progress-row">
                <span>{meta.progresso} / {meta.treinos_semana} treinos</span>
                <span className="meta-pct">{pct}%</span>
              </div>
              <div className="progress-bar large">
                <div className="progress-fill" style={{ width: `${pct}%` }} />
              </div>
              <button className="btn-secondary small" onClick={() => increment(meta.id)}>
                + Registrar treino
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
