import { useEffect, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";

// Mock data para demonstração (substituir por chamadas à API)
const mockStats = {
  totalMes: 12,
  horasTotais: 18.5,
  esporteFavorito: "Musculação",
  progressoMeta: 75,
};

const mockChartData = {
  labels: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"],
  values: [1, 0, 2, 1, 1, 2, 0],
};

export default function DashboardPage() {
  const { user } = useAuth();
  const canvasRef = useRef(null);
  const [stats] = useState(mockStats);

  useEffect(() => {
    // TODO: buscar dados reais via treinoService.listar(token)
    drawChart();
  }, []);

  function drawChart() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const { labels, values } = mockChartData;

    const w = canvas.width;
    const h = canvas.height;
    const pad = 40;
    const barW = (w - pad * 2) / labels.length - 10;
    const maxV = Math.max(...values) || 1;

    ctx.clearRect(0, 0, w, h);

    // Axes
    ctx.strokeStyle = "#444";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, 10);
    ctx.lineTo(pad, h - pad);
    ctx.lineTo(w - 10, h - pad);
    ctx.stroke();

    // Bars
    labels.forEach((label, i) => {
      const x = pad + i * (barW + 10) + 5;
      const barH = ((values[i] / maxV) * (h - pad - 20)) || 0;
      const y = h - pad - barH;

      const gradient = ctx.createLinearGradient(0, y, 0, h - pad);
      gradient.addColorStop(0, "#22c55e");
      gradient.addColorStop(1, "#166534");

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.roundRect(x, y, barW, barH, 4);
      ctx.fill();

      ctx.fillStyle = "#888";
      ctx.font = "11px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(label, x + barW / 2, h - pad + 14);

      if (values[i] > 0) {
        ctx.fillStyle = "#fff";
        ctx.font = "bold 11px sans-serif";
        ctx.fillText(values[i], x + barW / 2, y - 5);
      }
    });
  }

  return (
    <div className="page-content">
      <div className="page-header">
        <h2>Olá, {user?.nome} 👋</h2>
        <p className="page-subtitle">Resumo dos seus treinos</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{stats.totalMes}</div>
          <div className="stat-label">Treinos no mês</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.horasTotais}h</div>
          <div className="stat-label">Horas treinadas</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.esporteFavorito}</div>
          <div className="stat-label">Esporte favorito</div>
        </div>
        <div className="stat-card highlight">
          <div className="stat-value">{stats.progressoMeta}%</div>
          <div className="stat-label">Meta semanal</div>
          <div className="progress-bar">
            <div
              className="progress-fill"
              style={{ width: `${stats.progressoMeta}%` }}
            />
          </div>
        </div>
      </div>

      <div className="chart-section">
        <h3>Frequência semanal</h3>
        <canvas ref={canvasRef} width={580} height={200} className="chart-canvas" />
      </div>
    </div>
  );
}
