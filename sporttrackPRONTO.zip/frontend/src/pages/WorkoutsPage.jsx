import { useState } from "react";

const SPORTS = [
  "Musculação", "Corrida", "Natação", "Ciclismo",
  "Futebol", "Basquete", "Yoga", "CrossFit", "Outro"
];

const mockTreinos = [
  { id: 1, titulo: "Treino A - Peito e Tríceps", tipo_esporte: "Musculação", duracao_min: 60, data_treino: "2025-03-20", observacoes: "Foco em supino" },
  { id: 2, titulo: "Corrida matinal", tipo_esporte: "Corrida", duracao_min: 40, data_treino: "2025-03-22", observacoes: "5km em 24min" },
];

export default function WorkoutsPage() {
  const [treinos, setTreinos] = useState(mockTreinos);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState({
    titulo: "", tipo_esporte: "Musculação",
    duracao_min: "", data_treino: "", observacoes: ""
  });

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const openNew = () => {
    setForm({ titulo: "", tipo_esporte: "Musculação", duracao_min: "", data_treino: "", observacoes: "" });
    setEditItem(null);
    setShowForm(true);
  };

  const openEdit = (treino) => {
    setForm({ ...treino });
    setEditItem(treino.id);
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: chamar treinoService.criar(token, form) ou treinoService.atualizar(...)
    if (editItem) {
      setTreinos((prev) => prev.map((t) => (t.id === editItem ? { ...t, ...form } : t)));
    } else {
      setTreinos((prev) => [...prev, { ...form, id: Date.now() }]);
    }
    setShowForm(false);
  };

  const handleDelete = (id) => {
    // TODO: chamar treinoService.deletar(token, id)
    setTreinos((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <div className="page-content">
      <div className="page-header">
        <div>
          <h2>Meus Treinos</h2>
          <p className="page-subtitle">{treinos.length} treino(s) registrado(s)</p>
        </div>
        <button className="btn-primary" onClick={openNew}>+ Novo Treino</button>
      </div>

      {showForm && (
        <div className="modal-overlay">
          <div className="modal-card">
            <h3>{editItem ? "Editar Treino" : "Novo Treino"}</h3>
            <form className="treino-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Título</label>
                <input name="titulo" value={form.titulo} onChange={handleChange} placeholder="Ex: Treino A - Peito" required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Esporte</label>
                  <select name="tipo_esporte" value={form.tipo_esporte} onChange={handleChange}>
                    {SPORTS.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Duração (min)</label>
                  <input name="duracao_min" type="number" value={form.duracao_min} onChange={handleChange} min={1} required />
                </div>
              </div>
              <div className="form-group">
                <label>Data</label>
                <input name="data_treino" type="date" value={form.data_treino} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Observações</label>
                <textarea name="observacoes" value={form.observacoes} onChange={handleChange} rows={3} placeholder="Detalhes do treino..." />
              </div>
              <div className="form-actions">
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>Cancelar</button>
                <button type="submit" className="btn-primary">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="treinos-list">
        {treinos.length === 0 && (
          <p className="empty-state">Nenhum treino registrado. Comece agora!</p>
        )}
        {treinos.map((t) => (
          <div className="treino-card" key={t.id}>
            <div className="treino-info">
              <span className="treino-sport-badge">{t.tipo_esporte}</span>
              <h4>{t.titulo}</h4>
              <p className="treino-meta">{t.data_treino} · {t.duracao_min} min</p>
              {t.observacoes && <p className="treino-obs">{t.observacoes}</p>}
            </div>
            <div className="treino-actions">
              <button className="btn-icon" onClick={() => openEdit(t)} title="Editar">✎</button>
              <button className="btn-icon danger" onClick={() => handleDelete(t.id)} title="Excluir">✕</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
