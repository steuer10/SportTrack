import { useAuth } from "../context/AuthContext";

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: "⬡" },
  { id: "workouts", label: "Treinos", icon: "◈" },
  { id: "goals", label: "Metas", icon: "◎" },
];

export default function Navbar({ currentPage, onNavigate }) {
  const { user, logout } = useAuth();

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <span className="brand-icon">ST</span>
        <span className="brand-name">SportTrack</span>
      </div>

      <div className="navbar-links">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`nav-link ${currentPage === item.id ? "active" : ""}`}
            onClick={() => onNavigate(item.id)}
          >
            <span className="nav-icon">{item.icon}</span>
            <span className="nav-label">{item.label}</span>
          </button>
        ))}
      </div>

      <div className="navbar-user">
        <span className="user-name">{user?.nome}</span>
        <button className="btn-logout" onClick={logout}>
          Sair
        </button>
      </div>
    </nav>
  );
}
