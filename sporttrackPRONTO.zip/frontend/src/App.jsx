import { useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import AuthPage from "./pages/AuthPage";
import DashboardPage from "./pages/DashboardPage";
import WorkoutsPage from "./pages/WorkoutsPage";
import GoalsPage from "./pages/GoalsPage";
import Navbar from "./components/Navbar";

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState("dashboard");

  if (!user) return <AuthPage />;

  return (
    <div className="app-layout">
      <Navbar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="main-content">
        {currentPage === "dashboard" && <DashboardPage />}
        {currentPage === "workouts" && <WorkoutsPage />}
        {currentPage === "goals" && <GoalsPage />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
