const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:3333/api";

function getHeaders(token) {
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function request(method, path, body, token) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: getHeaders(token),
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: "Erro desconhecido" }));
    throw new Error(err.message || "Erro na requisição");
  }
  return res.json();
}

// Auth
export const authService = {
  login: (email, password) => request("POST", "/auth/login", { email, password }),
  register: (nome, email, password) => request("POST", "/auth/register", { nome, email, password }),
};

// Treinos
export const treinoService = {
  listar: (token) => request("GET", "/treinos", null, token),
  criar: (token, data) => request("POST", "/treinos", data, token),
  atualizar: (token, id, data) => request("PUT", `/treinos/${id}`, data, token),
  deletar: (token, id) => request("DELETE", `/treinos/${id}`, null, token),
};

// Metas
export const metaService = {
  listar: (token) => request("GET", "/metas", null, token),
  criar: (token, data) => request("POST", "/metas", data, token),
  atualizar: (token, id, data) => request("PUT", `/metas/${id}`, data, token),
};
