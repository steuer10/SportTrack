# Arquitetura SportTrack — Modelo C4

---

## Nível 1 — Diagrama de Contexto (System Context)

Visão de mais alto nível: quem usa o sistema e quais sistemas externos ele interage.

```
┌─────────────────────────────────────────────────────┐
│                    SportTrack                       │
│   Plataforma web de gerenciamento de treinos        │
└──────────────────────────┬──────────────────────────┘
                           │
              Acessa via navegador / app
                           │
                    ┌──────▼──────┐
                    │   Atleta    │
                    │  (Usuário)  │
                    └─────────────┘

Sistemas externos:
  ─ Render/Railway (Plataforma de deploy em nuvem)
  ─ PostgreSQL cloud (banco gerenciado no Render/Railway)
```

**Descrição:**
- O **Atleta** é o único usuário do sistema (pessoa física, usuário final).
- O sistema SportTrack é uma aplicação web acessada pelo navegador.
- Não há integrações com sistemas externos (redes sociais, wearables) na versão MVP.
- A infraestrutura de deploy (Render/Railway) é um sistema de suporte, não integração funcional.

---

## Nível 2 — Diagrama de Contêineres (Container Diagram)

Zoom dentro do sistema: quais são as aplicações/processos e como se comunicam.

```
                     ┌─────────────────────────────────────────────────────────────┐
                     │                     SportTrack (Sistema)                    │
                     │                                                             │
  Usuário            │  ┌────────────────┐   REST/JSON    ┌────────────────────┐  │
  (Browser)  ──────► │  │    Frontend    │ ─────────────► │      Backend       │  │
                     │  │  React (Vite)  │ ◄──────────── │  Node.js + Express  │  │
                     │  │  Porta: 5173   │   HTTP         │  Porta: 3333        │  │
                     │  └────────────────┘                └────────┬───────────┘  │
                     │                                             │               │
                     │                                   Prisma ORM│               │
                     │                                             │               │
                     │                                   ┌─────────▼───────────┐  │
                     │                                   │    PostgreSQL DB     │  │
                     │                                   │   Porta: 5432        │  │
                     │                                   └─────────────────────┘  │
                     └─────────────────────────────────────────────────────────────┘
```

**Contêineres:**

| Contêiner | Tecnologia | Responsabilidade |
|---|---|---|
| **Frontend** | React 18 + Vite | Interface do usuário, roteamento client-side, visualização de dados |
| **Backend** | Node.js + Express | API REST, regras de negócio, autenticação JWT |
| **Banco de Dados** | PostgreSQL + Prisma ORM | Persistência de dados relacionais |

**Comunicação:**
- Frontend → Backend: chamadas HTTP REST com JSON
- Frontend envia JWT no header `Authorization: Bearer <token>` em todas as rotas protegidas
- Backend → BD: via Prisma ORM (queries tipadas, migrations gerenciadas)

---

## Nível 3 — Diagrama de Componentes (Component Diagram)

### Frontend — Componentes internos

```
src/
├── main.jsx               ← Entry point (ReactDOM.createRoot)
├── App.jsx                ← Roteador de páginas + AuthProvider wrapper
│
├── context/
│   └── AuthContext.jsx    ← Gerencia estado de autenticação (user, token, login, logout)
│
├── services/
│   └── api.js             ← Camada de acesso à API (authService, treinoService, metaService)
│
├── components/
│   └── Navbar.jsx         ← Barra de navegação global
│
└── pages/
    ├── AuthPage.jsx        ← Login e Cadastro
    ├── DashboardPage.jsx   ← Estatísticas + gráfico de frequência (Chart.js / Canvas)
    ├── WorkoutsPage.jsx    ← CRUD de treinos
    └── GoalsPage.jsx       ← Metas semanais com barra de progresso
```

**Fluxo de dados no Frontend:**
```
AuthContext (estado global)
      │
      ├── App.jsx (lê user, decide qual página renderizar)
      │       │
      │       ├── AuthPage → chama authService → POST /api/auth/login ou /register
      │       ├── DashboardPage → chama treinoService.listar()
      │       ├── WorkoutsPage → chama treinoService.criar/atualizar/deletar()
      │       └── GoalsPage → chama metaService.criar/atualizar()
      │
      └── api.js (centraliza fetch + headers JWT)
```

### Backend — Componentes internos (planejamento para Semanas 1-2)

```
src/
├── server.js               ← Inicialização Express, middleware global
│
├── routes/
│   ├── auth.routes.js      ← POST /api/auth/login, POST /api/auth/register
│   ├── treino.routes.js    ← GET/POST /api/treinos, PUT/DELETE /api/treinos/:id
│   └── meta.routes.js      ← GET/POST /api/metas, PUT /api/metas/:id
│
├── controllers/
│   ├── auth.controller.js  ← Lógica de autenticação (bcrypt, geração de JWT)
│   ├── treino.controller.js← CRUD de treinos com validação
│   └── meta.controller.js  ← CRUD de metas com cálculo de progresso
│
├── middleware/
│   └── auth.middleware.js  ← Verificação de JWT em rotas protegidas
│
└── prisma/
    └── schema.prisma       ← Definição dos modelos Usuario, Treino, Meta
```

---

## Nível 4 — Código (Resumo — Modelo de Dados)

### Prisma Schema (modelo de dados definitivo)

```prisma
model Usuario {
  id         Int       @id @default(autoincrement())
  nome       String
  email      String    @unique
  senha      String
  criadoEm  DateTime  @default(now())
  treinos    Treino[]
  metas      Meta[]
}

model Treino {
  id          Int      @id @default(autoincrement())
  titulo      String
  tipoEsporte String
  duracaoMin  Int
  observacoes String?
  dataTreino  DateTime
  usuarioId   Int
  usuario     Usuario  @relation(fields: [usuarioId], references: [id])
  criadoEm   DateTime @default(now())
}

model Meta {
  id            Int     @id @default(autoincrement())
  treinosSemana Int
  progresso     Int     @default(0)
  ativa         Boolean @default(true)
  usuarioId     Int
  usuario       Usuario @relation(fields: [usuarioId], references: [id])
  criadoEm     DateTime @default(now())
}
```

---

## Decisões Arquiteturais (ADR)

### ADR-001: Separação Frontend/Backend como contêineres independentes
**Contexto:** Alternativa seria SSR com Next.js.  
**Decisão:** SPA (React) + API REST separada.  
**Justificativa:** Permite deploy independente, maior clareza de responsabilidades e facilita futura evolução mobile.

### ADR-002: Autenticação JWT stateless
**Contexto:** Alternativa seria sessão server-side.  
**Decisão:** JWT armazenado no localStorage.  
**Justificativa:** Mais simples para MVP, sem necessidade de gerenciamento de sessão no servidor.  
**Trade-off:** Menor controle de revogação de token (aceitável no escopo do projeto).

### ADR-003: ORM Prisma sobre queries SQL diretas
**Contexto:** Alternativa seria `pg` com SQL raw.  
**Decisão:** Prisma ORM.  
**Justificativa:** Type-safety, migrations versionadas, DX superior para o escopo acadêmico.

---

## Ajustes de Requisitos (Interação 2)

### Novos requisitos identificados durante implementação:

| ID | Tipo | Descrição | Origem |
|---|---|---|---|
| RF-08 | Funcional (novo) | Filtrar treinos por tipo de esporte e período de data | Necessidade identificada ao modelar a listagem |
| RF-09 | Funcional (novo) | Exibir histórico de progresso de metas (não apenas estado atual) | Necessidade identificada ao modelar GoalsPage |
| RNF-05 | Não Funcional (novo) | Tokens JWT com expiração de 7 dias; refresh token não previsto no MVP | Decisão de segurança tomada durante implementação |
| RNF-06 | Não Funcional (revisão) | Senhas armazenadas com bcrypt (salt rounds = 10) — detalhe ausente no README original | Boa prática de segurança |
| RF-03 | Funcional (revisão) | Paginação do histórico de treinos (limit/offset) quando > 20 registros | Performance identificada como risco futuro |

### Requisitos removidos / adiados:

| ID | Descrição | Motivo |
|---|---|---|
| RF-07 (meta semanal) | Progresso automático via contagem de treinos cadastrados | Adiado para Semana 3; implementação manual primeiro |
