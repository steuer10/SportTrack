const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcrypt");

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Iniciando seed...");

  // Cria usuário de demonstração
  const senha = await bcrypt.hash("123456", 10);
  const usuario = await prisma.usuario.upsert({
    where: { email: "demo@sporttrack.com" },
    update: {},
    create: { nome: "Vinicius Demo", email: "demo@sporttrack.com", senha },
  });

  console.log(`✅ Usuário criado: ${usuario.email}`);

  // Treinos dos últimos 30 dias
  const esportes = ["Musculação", "Corrida", "Natação", "Ciclismo", "Yoga"];
  const titulos  = {
    "Musculação": ["Treino A – Peito e Tríceps", "Treino B – Costas e Bíceps", "Treino C – Pernas"],
    "Corrida":    ["Corrida matinal", "Treino intervalado", "Long run fim de semana"],
    "Natação":    ["Nado livre 1km", "Treino de técnica"],
    "Ciclismo":   ["Pedal urbano", "Ciclismo mountain bike"],
    "Yoga":       ["Yoga relaxamento", "Vinyasa flow"],
  };

  const treinosDados = [];
  for (let i = 29; i >= 0; i--) {
    if (Math.random() < 0.45) { // ~45% dos dias com treino
      const esporte = esportes[Math.floor(Math.random() * esportes.length)];
      const listaTitulos = titulos[esporte];
      const titulo = listaTitulos[Math.floor(Math.random() * listaTitulos.length)];
      const data = new Date();
      data.setDate(data.getDate() - i);
      data.setHours(7 + Math.floor(Math.random() * 14), 0, 0, 0);

      treinosDados.push({
        titulo,
        tipoEsporte: esporte,
        duracaoMin: 30 + Math.floor(Math.random() * 60),
        dataTreino: data,
        usuarioId: usuario.id,
        observacoes: Math.random() > 0.5 ? "Treino dentro do planejado." : null,
      });
    }
  }

  await prisma.treino.deleteMany({ where: { usuarioId: usuario.id } });
  await prisma.treino.createMany({ data: treinosDados });
  console.log(`✅ ${treinosDados.length} treinos criados`);

  // Meta semanal
  await prisma.meta.deleteMany({ where: { usuarioId: usuario.id } });
  await prisma.meta.create({
    data: { treinosSemana: 4, progresso: 0, ativa: true, usuarioId: usuario.id },
  });
  console.log("✅ Meta semanal criada (4 treinos/semana)");

  console.log("\n🎉 Seed concluído!");
  console.log("   Login: demo@sporttrack.com");
  console.log("   Senha: 123456");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
