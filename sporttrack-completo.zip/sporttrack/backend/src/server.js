require("dotenv").config();
const express = require("express");
const { PrismaClient } = require("@prisma/client");

const app    = express();
const prisma = new PrismaClient();

app.use(express.json());

// CORS
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// Rotas
app.use("/api/auth",    require("./routes/auth.routes"));
app.use("/api/treinos", require("./routes/treino.routes"));
app.use("/api/metas",   require("./routes/meta.routes"));
app.use("/api/stats",   require("./routes/stats.routes"));

app.get("/", (_req, res) => res.json({ status: "SportTrack API ok", version: "1.0" }));

// 404
app.use((_req, res) => res.status(404).json({ message: "Rota não encontrada" }));

// Error handler global
app.use((err, _req, res, _next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ message: "Erro interno no servidor" });
});

const PORT = process.env.PORT || 3333;
const server = app.listen(PORT, () =>
  console.log(`🚀 Servidor rodando na porta ${PORT}`)
);

// Graceful shutdown
const shutdown = async () => {
  console.log("Encerrando servidor...");
  await prisma.$disconnect();
  server.close(() => process.exit(0));
};
process.on("SIGTERM", shutdown);
process.on("SIGINT",  shutdown);
