const router = require("express").Router();
const auth = require("../middleware/auth.middleware");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// GET /api/metas
router.get("/", auth, async (req, res) => {
  try {
    const metas = await prisma.meta.findMany({
      where: { usuarioId: req.usuarioId },
      orderBy: { criadoEm: "desc" },
    });
    res.json(metas);
  } catch (err) {
    console.error("listar metas error:", err);
    res.status(500).json({ message: "Erro ao buscar metas" });
  }
});

// POST /api/metas
router.post("/", auth, async (req, res) => {
  try {
    const { treinosSemana } = req.body;
    if (!treinosSemana)
      return res.status(400).json({ message: "treinosSemana é obrigatório" });

    const meta = await prisma.meta.create({
      data: {
        treinosSemana: Number(treinosSemana),
        usuarioId: req.usuarioId,
      },
    });
    res.status(201).json(meta);
  } catch (err) {
    console.error("criar meta error:", err);
    res.status(500).json({ message: "Erro ao criar meta" });
  }
});

// PUT /api/metas/:id
router.put("/:id", auth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const meta = await prisma.meta.findFirst({
      where: { id, usuarioId: req.usuarioId },
    });
    if (!meta)
      return res.status(404).json({ message: "Meta não encontrada" });

    const atualizada = await prisma.meta.update({
      where: { id },
      data: {
        progresso: req.body.progresso !== undefined ? Number(req.body.progresso) : undefined,
        ativa: req.body.ativa !== undefined ? Boolean(req.body.ativa) : undefined,
        treinosSemana: req.body.treinosSemana ? Number(req.body.treinosSemana) : undefined,
      },
    });
    res.json(atualizada);
  } catch (err) {
    console.error("atualizar meta error:", err);
    res.status(500).json({ message: "Erro ao atualizar meta" });
  }
});

// DELETE /api/metas/:id
router.delete("/:id", auth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const meta = await prisma.meta.findFirst({
      where: { id, usuarioId: req.usuarioId },
    });
    if (!meta)
      return res.status(404).json({ message: "Meta não encontrada" });

    await prisma.meta.delete({ where: { id } });
    res.status(204).send();
  } catch (err) {
    console.error("deletar meta error:", err);
    res.status(500).json({ message: "Erro ao deletar meta" });
  }
});

module.exports = router;
