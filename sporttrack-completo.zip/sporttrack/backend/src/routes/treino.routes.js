const router = require("express").Router();
const auth = require("../middleware/auth.middleware");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// GET /api/treinos
router.get("/", auth, async (req, res) => {
  try {
    const treinos = await prisma.treino.findMany({
      where: { usuarioId: req.usuarioId },
      orderBy: { dataTreino: "desc" },
    });
    res.json(treinos);
  } catch (err) {
    console.error("listar treinos error:", err);
    res.status(500).json({ message: "Erro ao buscar treinos" });
  }
});

// POST /api/treinos
router.post("/", auth, async (req, res) => {
  try {
    const { titulo, tipoEsporte, duracaoMin, observacoes, dataTreino } = req.body;
    if (!titulo || !tipoEsporte || !duracaoMin || !dataTreino)
      return res.status(400).json({ message: "Campos obrigatórios faltando" });

    const treino = await prisma.treino.create({
      data: {
        titulo,
        tipoEsporte,
        duracaoMin: Number(duracaoMin),
        observacoes: observacoes || null,
        dataTreino: new Date(dataTreino),
        usuarioId: req.usuarioId,
      },
    });
    res.status(201).json(treino);
  } catch (err) {
    console.error("criar treino error:", err);
    res.status(500).json({ message: "Erro ao criar treino" });
  }
});

// PUT /api/treinos/:id
router.put("/:id", auth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const treino = await prisma.treino.findFirst({
      where: { id, usuarioId: req.usuarioId },
    });
    if (!treino)
      return res.status(404).json({ message: "Treino não encontrado" });

    const atualizado = await prisma.treino.update({
      where: { id },
      data: {
        titulo: req.body.titulo,
        tipoEsporte: req.body.tipoEsporte,
        duracaoMin: Number(req.body.duracaoMin),
        observacoes: req.body.observacoes || null,
        dataTreino: new Date(req.body.dataTreino),
      },
    });
    res.json(atualizado);
  } catch (err) {
    console.error("atualizar treino error:", err);
    res.status(500).json({ message: "Erro ao atualizar treino" });
  }
});

// DELETE /api/treinos/:id
router.delete("/:id", auth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const treino = await prisma.treino.findFirst({
      where: { id, usuarioId: req.usuarioId },
    });
    if (!treino)
      return res.status(404).json({ message: "Treino não encontrado" });

    await prisma.treino.delete({ where: { id } });
    res.status(204).send();
  } catch (err) {
    console.error("deletar treino error:", err);
    res.status(500).json({ message: "Erro ao deletar treino" });
  }
});

module.exports = router;
