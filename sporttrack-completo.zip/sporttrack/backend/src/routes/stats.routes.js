const router = require("express").Router();
const auth = require("../middleware/auth.middleware");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// GET /api/stats  — dados consolidados para o Dashboard
router.get("/", auth, async (req, res) => {
  try {
    const uid = req.usuarioId;
    const agora = new Date();

    // Início e fim do mês atual
    const inicioMes = new Date(agora.getFullYear(), agora.getMonth(), 1);
    const fimMes    = new Date(agora.getFullYear(), agora.getMonth() + 1, 0, 23, 59, 59);

    // Início da semana atual (segunda-feira)
    const diaSemana = (agora.getDay() + 6) % 7; // 0=Seg … 6=Dom
    const inicioSemana = new Date(agora);
    inicioSemana.setDate(agora.getDate() - diaSemana);
    inicioSemana.setHours(0, 0, 0, 0);

    // Últimos 7 dias para o gráfico
    const inicio7Dias = new Date(agora);
    inicio7Dias.setDate(agora.getDate() - 6);
    inicio7Dias.setHours(0, 0, 0, 0);

    const [treinosMes, treinos7Dias, metaAtiva] = await Promise.all([
      prisma.treino.findMany({
        where: { usuarioId: uid, dataTreino: { gte: inicioMes, lte: fimMes } },
        select: { tipoEsporte: true, duracaoMin: true },
      }),
      prisma.treino.findMany({
        where: { usuarioId: uid, dataTreino: { gte: inicio7Dias } },
        select: { dataTreino: true },
      }),
      prisma.meta.findFirst({
        where: { usuarioId: uid, ativa: true },
        orderBy: { criadoEm: "desc" },
      }),
    ]);

    // Totais do mês
    const totalMes      = treinosMes.length;
    const minutosTotais = treinosMes.reduce((acc, t) => acc + t.duracaoMin, 0);
    const horasTotais   = Math.round((minutosTotais / 60) * 10) / 10;

    // Esporte mais praticado no mês
    const contagem = {};
    treinosMes.forEach((t) => { contagem[t.tipoEsporte] = (contagem[t.tipoEsporte] || 0) + 1; });
    const esporteFavorito = Object.keys(contagem).sort((a, b) => contagem[b] - contagem[a])[0] || null;

    // Progresso da meta: treinos feitos na semana atual
    let progressoMeta     = 0;
    let treinosSemanaAlvo = 0;
    if (metaAtiva) {
      const treinosSemana = await prisma.treino.count({
        where: { usuarioId: uid, dataTreino: { gte: inicioSemana } },
      });
      treinosSemanaAlvo = metaAtiva.treinosSemana;
      progressoMeta     = Math.min(Math.round((treinosSemana / metaAtiva.treinosSemana) * 100), 100);

      // Atualiza progresso no banco se mudou
      if (treinosSemana !== metaAtiva.progresso) {
        await prisma.meta.update({
          where: { id: metaAtiva.id },
          data: { progresso: treinosSemana },
        });
      }
    }

    // Frequência dos últimos 7 dias (índice 0=Seg, 6=Dom)
    const frequencia = [0, 0, 0, 0, 0, 0, 0];
    treinos7Dias.forEach((t) => {
      const idx = (new Date(t.dataTreino).getDay() + 6) % 7;
      frequencia[idx]++;
    });

    res.json({
      totalMes,
      horasTotais,
      esporteFavorito,
      progressoMeta,
      treinosSemanaAlvo,
      frequencia, // array [Seg, Ter, Qua, Qui, Sex, Sáb, Dom]
    });
  } catch (err) {
    console.error("stats error:", err);
    res.status(500).json({ message: "Erro ao calcular estatísticas" });
  }
});

module.exports = router;
