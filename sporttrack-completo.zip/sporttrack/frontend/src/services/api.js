const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:3333/api";

function getHeaders(token) {
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function request(method, path, body, token) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: getHeaders(token),
    body: body ? JSON.stringify(body) : undefined,
  });

  // DELETE retorna 204 sem body
  if (res.status === 204) return null;

  const data = await res.json().catch(() => ({ message: "Erro desconhecido" }));
  if (!res.ok) throw new Error(data.message || "Erro na requisição");
  return data;
}

// Auth
export const authService = {
  login:    (email, password)         => request("POST", "/auth/login",    { email, password }),
  register: (nome, email, password)   => request("POST", "/auth/register", { nome, email, password }),
};

// Treinos
export const treinoService = {
  listar:    (token)          => request("GET",    "/treinos",        null,  token),
  criar:     (token, data)    => request("POST",   "/treinos",        data,  token),
  atualizar: (token, id, data)=> request("PUT",    `/treinos/${id}`,  data,  token),
  deletar:   (token, id)      => request("DELETE", `/treinos/${id}`,  null,  token),
};

// Metas
export const metaService = {
  listar:    (token)          => request("GET",  "/metas",       null, token),
  criar:     (token, data)    => request("POST", "/metas",       data, token),
  atualizar: (token, id, data)=> request("PUT",  `/metas/${id}`, data, token),
  deletar:   (token, id)      => request("DELETE",`/metas/${id}`,null, token),
};

// Stats (Dashboard)
export const statsService = {
  buscar: (token) => request("GET", "/stats", null, token),
};
