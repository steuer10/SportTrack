import { useState, useEffect, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { treinoService } from "../services/api";

const SPORTS = [
  "Musculação", "Corrida", "Natação", "Ciclismo",
  "Futebol", "Basquete", "Yoga", "CrossFit", "Outro",
];

const EMPTY_FORM = {
  titulo: "", tipoEsporte: "Musculação",
  duracaoMin: "", dataTreino: "", observacoes: "",
};

function formatDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  return d.toLocaleDateString("pt-BR");
}

function toInputDate(dateStr) {
  if (!dateStr) return "";
  return new Date(dateStr).toISOString().split("T")[0];
}

export default function WorkoutsPage() {
  const { token } = useAuth();
  const [treinos, setTreinos] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");

  const loadTreinos = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const data = await treinoService.listar(token);
      setTreinos(data);
    } catch (err) {
      setError("Erro ao carregar treinos: " + err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { loadTreinos(); }, [loadTreinos]);

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const openNew = () => {
    const hoje = new Date().toISOString().split("T")[0];
    setForm({ ...EMPTY_FORM, dataTreino: hoje });
    setEditItem(null);
    setFormError("");
    setShowForm(true);
  };

  const openEdit = (treino) => {
    setForm({
      titulo: treino.titulo,
      tipoEsporte: treino.tipoEsporte,
      duracaoMin: treino.duracaoMin,
      dataTreino: toInputDate(treino.dataTreino),
      observacoes: treino.observacoes || "",
    });
    setEditItem(treino.id);
    setFormError("");
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setFormError("");
    try {
      const payload = {
        titulo: form.titulo,
        tipoEsporte: form.tipoEsporte,
        duracaoMin: Number(form.duracaoMin),
        dataTreino: form.dataTreino,
        observacoes: form.observacoes || undefined,
      };
      if (editItem) {
        await treinoService.atualizar(token, editItem, payload);
      } else {
        await treinoService.criar(token, payload);
      }
      setShowForm(false);
      await loadTreinos();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Deseja excluir este treino?")) return;
    try {
      await treinoService.deletar(token, id);
      setTreinos((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      setError("Erro ao excluir treino: " + err.message);
    }
  };

  return (
    <div className="page-content">
      <div className="page-header">
        <div>
          <h2>Meus Treinos</h2>
          <p className="page-subtitle">{treinos.length} treino(s) registrado(s)</p>
        </div>
        <button className="btn-primary" onClick={openNew}>+ Novo Treino</button>
      </div>

      {error && <p className="form-error" style={{ marginBottom: 16 }}>{error}</p>}

      {showForm && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal-card">
            <h3>{editItem ? "Editar Treino" : "Novo Treino"}</h3>
            <form className="treino-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Título</label>
                <input
                  name="titulo"
                  value={form.titulo}
                  onChange={handleChange}
                  placeholder="Ex: Treino A - Peito e Tríceps"
                  required
                />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Esporte</label>
                  <select name="tipoEsporte" value={form.tipoEsporte} onChange={handleChange}>
                    {SPORTS.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Duração (min)</label>
                  <input
                    name="duracaoMin"
                    type="number"
                    value={form.duracaoMin}
                    onChange={handleChange}
                    min={1}
                    required
                  />
                </div>
              </div>
              <div className="form-group">
                <label>Data</label>
                <input
                  name="dataTreino"
                  type="date"
                  value={form.dataTreino}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Observações</label>
                <textarea
                  name="observacoes"
                  value={form.observacoes}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Detalhes do treino..."
                />
              </div>
              {formError && <p className="form-error">{formError}</p>}
              <div className="form-actions">
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>
                  Cancelar
                </button>
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? "Salvando..." : "Salvar"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading-placeholder">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton" style={{ height: 90, borderRadius: 10, marginBottom: 10 }} />
          ))}
        </div>
      ) : (
        <div className="treinos-list">
          {treinos.length === 0 && (
            <div className="empty-state">
              <p>Nenhum treino registrado ainda.</p>
              <button className="btn-primary" onClick={openNew} style={{ marginTop: 12 }}>
                Registrar primeiro treino
              </button>
            </div>
          )}
          {treinos.map((t) => (
            <div className="treino-card" key={t.id}>
              <div className="treino-info">
                <span className="treino-sport-badge">{t.tipoEsporte}</span>
                <h4>{t.titulo}</h4>
                <p className="treino-meta">
                  {formatDate(t.dataTreino)} · {t.duracaoMin} min
                </p>
                {t.observacoes && <p className="treino-obs">{t.observacoes}</p>}
              </div>
              <div className="treino-actions">
                <button className="btn-icon" onClick={() => openEdit(t)} title="Editar">✎</button>
                <button className="btn-icon danger" onClick={() => handleDelete(t.id)} title="Excluir">✕</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
