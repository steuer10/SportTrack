import { useEffect, useRef, useState, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { statsService } from "../services/api";

const LABELS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];

export default function DashboardPage() {
  const { user, token } = useAuth();
  const canvasRef = useRef(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadStats = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const data = await statsService.buscar(token);
      setStats(data);
    } catch (err) {
      setError("Erro ao carregar dados: " + err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { loadStats(); }, [loadStats]);

  useEffect(() => {
    if (stats) drawChart(stats.frequencia);
  }, [stats]);

  function drawChart(valores) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx   = canvas.getContext("2d");
    const w     = canvas.width;
    const h     = canvas.height;
    const pad   = 40;
    const barW  = (w - pad * 2) / LABELS.length - 10;
    const maxV  = Math.max(...valores, 1);

    ctx.clearRect(0, 0, w, h);

    // Eixos
    ctx.strokeStyle = "#2a2f2c";
    ctx.lineWidth   = 1;
    ctx.beginPath();
    ctx.moveTo(pad, 10);
    ctx.lineTo(pad, h - pad);
    ctx.lineTo(w - 10, h - pad);
    ctx.stroke();

    LABELS.forEach((label, i) => {
      const x    = pad + i * (barW + 10) + 5;
      const barH = ((valores[i] / maxV) * (h - pad - 20)) || 0;
      const y    = h - pad - barH;

      if (barH > 0) {
        const grad = ctx.createLinearGradient(0, y, 0, h - pad);
        grad.addColorStop(0, "#22c55e");
        grad.addColorStop(1, "#166534");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, y, barW, barH, 4);
        ctx.fill();

        ctx.fillStyle = "#fff";
        ctx.font      = "bold 11px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(valores[i], x + barW / 2, y - 5);
      } else {
        ctx.fillStyle = "#2a2f2c";
        ctx.beginPath();
        ctx.roundRect(x, h - pad - 4, barW, 4, 2);
        ctx.fill();
      }

      ctx.fillStyle = "#8a9490";
      ctx.font      = "11px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(label, x + barW / 2, h - pad + 14);
    });
  }

  return (
    <div className="page-content">
      <div className="page-header">
        <div>
          <h2>Olá, {user?.nome} 👋</h2>
          <p className="page-subtitle">Resumo dos seus treinos</p>
        </div>
        <button className="btn-secondary" onClick={loadStats} disabled={loading} style={{ fontSize: 13 }}>
          ↺ Atualizar
        </button>
      </div>

      {error && <p className="form-error" style={{ marginBottom: 16 }}>{error}</p>}

      {loading ? (
        <div className="loading-placeholder">
          <div className="skeleton" style={{ height: 110, borderRadius: 10, marginBottom: 14 }} />
          <div className="skeleton" style={{ height: 220, borderRadius: 10 }} />
        </div>
      ) : stats ? (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-value">{stats.totalMes}</div>
              <div className="stat-label">Treinos no mês</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{stats.horasTotais}h</div>
              <div className="stat-label">Horas treinadas</div>
            </div>
            <div className="stat-card">
              <div
                className="stat-value"
                style={{ fontSize: (stats.esporteFavorito || "").length > 8 ? "1rem" : undefined }}
              >
                {stats.esporteFavorito || "—"}
              </div>
              <div className="stat-label">Esporte favorito</div>
            </div>
            <div className="stat-card highlight">
              <div className="stat-value">{stats.progressoMeta}%</div>
              <div className="stat-label">
                Meta semanal{stats.treinosSemanaAlvo ? ` (${stats.treinosSemanaAlvo}×/sem)` : ""}
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${stats.progressoMeta}%` }} />
              </div>
            </div>
          </div>

          <div className="chart-section">
            <h3>Frequência — últimos 7 dias</h3>
            <canvas ref={canvasRef} width={580} height={200} className="chart-canvas" />
          </div>
        </>
      ) : null}
    </div>
  );
}
