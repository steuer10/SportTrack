import { useState, useEffect, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { metaService, treinoService } from "../services/api";

export default function GoalsPage() {
  const { token } = useAuth();
  const [metas, setMetas] = useState([]);
  const [form, setForm] = useState({ treinosSemana: 3 });
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");

  const loadMetas = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const [metasData, treinos] = await Promise.all([
        metaService.listar(token),
        treinoService.listar(token),
      ]);

      // Treinos desta semana (segunda até agora)
      const hoje = new Date();
      const diaSemana = (hoje.getDay() + 6) % 7;
      const inicioSemana = new Date(hoje);
      inicioSemana.setDate(hoje.getDate() - diaSemana);
      inicioSemana.setHours(0, 0, 0, 0);

      const treinosSemana = treinos.filter((t) => new Date(t.dataTreino) >= inicioSemana).length;

      // Sincroniza progresso da meta ativa no banco
      const metasComProgresso = await Promise.all(
        metasData.map(async (meta) => {
          if (meta.ativa) {
            const novoProgresso = Math.min(treinosSemana, meta.treinosSemana);
            if (novoProgresso !== meta.progresso) {
              try {
                await metaService.atualizar(token, meta.id, { progresso: novoProgresso });
              } catch { /* silencia */ }
              return { ...meta, progresso: novoProgresso };
            }
          }
          return meta;
        })
      );

      setMetas(metasComProgresso);
    } catch (err) {
      setError("Erro ao carregar metas: " + err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { loadMetas(); }, [loadMetas]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setFormError("");
    try {
      // Desativa meta ativa anterior
      const metaAtiva = metas.find((m) => m.ativa);
      if (metaAtiva) {
        await metaService.atualizar(token, metaAtiva.id, { ativa: false });
      }
      await metaService.criar(token, { treinosSemana: Number(form.treinosSemana) });
      setShowForm(false);
      await loadMetas();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const toggleAtiva = async (meta) => {
    try {
      await metaService.atualizar(token, meta.id, { ativa: !meta.ativa });
      setMetas((prev) =>
        prev.map((m) => (m.id === meta.id ? { ...m, ativa: !m.ativa } : m))
      );
    } catch (err) {
      setError("Erro ao atualizar meta: " + err.message);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm("Deseja excluir esta meta?")) return;
    try {
      await metaService.deletar(token, id);
      setMetas((prev) => prev.filter((m) => m.id !== id));
    } catch (err) {
      setError("Erro ao excluir meta: " + err.message);
    }
  };

  return (
    <div className="page-content">
      <div className="page-header">
        <div>
          <h2>Metas Semanais</h2>
          <p className="page-subtitle">Acompanhe suas metas de treino</p>
        </div>
        <button className="btn-primary" onClick={() => { setFormError(""); setShowForm(true); }}>
          + Nova Meta
        </button>
      </div>

      {error && <p className="form-error" style={{ marginBottom: 16 }}>{error}</p>}

      {showForm && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal-card">
            <h3>Nova Meta Semanal</h3>
            <form onSubmit={handleSave}>
              <div className="form-group">
                <label>Treinos por semana</label>
                <input
                  type="number"
                  min={1}
                  max={14}
                  value={form.treinosSemana}
                  onChange={(e) => setForm({ treinosSemana: e.target.value })}
                  required
                />
                <small>A meta ativa anterior será desativada automaticamente.</small>
              </div>
              {formError && <p className="form-error">{formError}</p>}
              <div className="form-actions">
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>
                  Cancelar
                </button>
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? "Salvando..." : "Salvar"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading-placeholder">
          {[1, 2].map((i) => (
            <div key={i} className="skeleton" style={{ height: 150, borderRadius: 10, marginBottom: 12 }} />
          ))}
        </div>
      ) : (
        <div className="metas-list">
          {metas.length === 0 && (
            <div className="empty-state">
              <p>Nenhuma meta cadastrada ainda.</p>
              <button className="btn-primary" onClick={() => setShowForm(true)} style={{ marginTop: 12 }}>
                Criar primeira meta
              </button>
            </div>
          )}
          {metas.map((meta) => {
            const pct = Math.min(Math.round((meta.progresso / meta.treinosSemana) * 100), 100);
            return (
              <div className={`meta-card ${!meta.ativa ? "inactive" : ""}`} key={meta.id}>
                <div className="meta-header">
                  <h4>
                    {meta.treinosSemana} treinos / semana
                    {!meta.ativa && <span className="meta-tag">Inativa</span>}
                  </h4>
                  <span className={`meta-badge ${pct >= 100 ? "complete" : ""}`}>
                    {pct >= 100 ? "✓ Concluída!" : "Em andamento"}
                  </span>
                </div>

                <div className="meta-progress-row">
                  <span>{meta.progresso} / {meta.treinosSemana} treinos esta semana</span>
                  <span className="meta-pct">{pct}%</span>
                </div>

                <div className="progress-bar large">
                  <div className="progress-fill" style={{ width: `${pct}%` }} />
                </div>

                <div className="meta-footer">
                  <button className="btn-secondary small" onClick={() => toggleAtiva(meta)}>
                    {meta.ativa ? "Desativar" : "Ativar"}
                  </button>
                  <button className="btn-icon danger" onClick={() => handleDelete(meta.id)} title="Excluir">✕</button>
                  {meta.ativa && (
                    <span className="meta-hint">Progresso calculado pelos treinos da semana</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
