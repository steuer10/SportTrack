import { createContext, useContext, useState, useEffect } from "react";
import { authService } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restaura sessão ao carregar a página
  useEffect(() => {
    const savedToken = localStorage.getItem("sporttrack_token");
    const savedUser = localStorage.getItem("sporttrack_user");
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const data = await authService.login(email, password);
    setUser(data.usuario);
    setToken(data.token);
    localStorage.setItem("sporttrack_token", data.token);
    localStorage.setItem("sporttrack_user", JSON.stringify(data.usuario));
  };

  const register = async (nome, email, password) => {
    const data = await authService.register(nome, email, password);
    setUser(data.usuario);
    setToken(data.token);
    localStorage.setItem("sporttrack_token", data.token);
    localStorage.setItem("sporttrack_user", JSON.stringify(data.usuario));
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("sporttrack_token");
    localStorage.removeItem("sporttrack_user");
  };

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
